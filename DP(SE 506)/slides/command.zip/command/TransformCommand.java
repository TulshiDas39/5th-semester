package command;

import java.util.ArrayList;
import java.util.Scanner;

public class TransformCommand implements ICommand {
	ArrayList<Integer> oldX, oldY;

	Scanner scanner = new Scanner(System.in);
	int x, y;
	Circle circle;

	public TransformCommand(Circle circle, int x, int y) {
		oldX = new ArrayList<>();
		oldY = new ArrayList<>();
		this.circle = circle;
		oldX.add(x);
		oldY.add(y);
	}

	int i = 0;
	int j = 1;

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		int n = 0;
		while (n != 4) {
			System.out.println("Enter your choice:\n1.Transform\n2.Undo\n3.Redo\n4.Exit");
			n = scanner.nextInt();
			scanner.nextLine();

			if (n == 1) {
				i = 0;
				System.out.println("Enter position:");
				System.out.println("Enter x: ");
				int x = scanner.nextInt();
				scanner.nextLine();
				System.out.println("Enter y: ");
				int y = scanner.nextInt();
				scanner.nextLine();
				oldX.add(x);
				oldY.add(y);
				circle.transform(x, y);
				j += 1;
			}

			else if (n == 2) {
				if (oldX.size() >= 1) {
					i++;
					j = i + 1;
					circle.undo(oldX.get(oldX.size() - (i + 1)), oldY.get(oldY.size() - (i + 1)));
				} else {
					System.out.println("Remain same position " + oldX.get(0) + " " + oldY.get(0));
				}
			} else if (n == 3) {
				if(j<=oldX.size()) {
				i = 0;
				circle.redo(oldX.get(j-1), oldY.get(j-1));
				}
				else {
					System.out.println("Not possible");
				}
			}
		}

	}

}
