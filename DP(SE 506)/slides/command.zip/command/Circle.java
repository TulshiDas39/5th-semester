package command;

public class Circle {
	int x, y;

	public Circle(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public void transform(int x, int y) {
		System.out.println("Cricle is transformed in position " + x + " " + y);
	}

	public void undo(int x, int y) {
		System.out.println("Circle is transformed in previous position " + x + " " + y);
	}

	public void redo(int x, int y) {
		System.out.println("Circle is transformed in next position " + x + " " + y);
	}
}
