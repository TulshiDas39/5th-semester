package command;

public class Invoker {
	public void execute(ICommand command) {
		command.execute();
	}
}
