package command;

public interface ICommand {
	public void execute();
}
