package command;

public class Main {

	public static void main(String[] args) {
		ICommand command = new TransformCommand(new Circle(10, 10), 10, 10);
		Invoker invoker = new Invoker();

		invoker.execute(command);
	}
}
