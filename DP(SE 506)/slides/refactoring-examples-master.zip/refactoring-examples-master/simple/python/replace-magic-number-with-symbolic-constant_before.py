def potentialEnergy(mass, height):
    return mass * height * 9.81