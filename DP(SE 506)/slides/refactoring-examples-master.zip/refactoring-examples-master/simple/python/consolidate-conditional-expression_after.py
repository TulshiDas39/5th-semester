def disabilityAmount():
    if isNotEligableForDisability():
        return 0
    # compute the disability amount
    #...