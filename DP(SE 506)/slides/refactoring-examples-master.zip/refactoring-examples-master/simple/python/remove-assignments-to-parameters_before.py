def discount(inputVal, quantity):
    if inputVal > 50:
        inputVal -= 2
    #...