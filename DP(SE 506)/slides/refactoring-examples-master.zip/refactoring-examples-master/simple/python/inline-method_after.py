class PizzaDelivery:
  #...
  def getRating(self):
    return 2 if self.numberOfLateDeliveries > 5 else 1