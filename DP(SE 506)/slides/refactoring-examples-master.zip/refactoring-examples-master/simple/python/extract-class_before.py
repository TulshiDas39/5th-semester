class Soldier:
    self.health = 0
    self.damage = 0
    self.weaponStatus = 0

    def getDamage(self):
        #...

    def attack(self):
        #...