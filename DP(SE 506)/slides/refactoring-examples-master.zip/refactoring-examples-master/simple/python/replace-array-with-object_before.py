row = [None * 2]
row[0] = "Liverpool"
row[1] = "15"