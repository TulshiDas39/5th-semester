perimeter = 2 * (height + width)
print(perimeter);
area = height * width
print(area)