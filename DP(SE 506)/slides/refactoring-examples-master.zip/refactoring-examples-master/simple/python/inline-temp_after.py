def hasDiscount(order):
    return order.basePrice() > 1000