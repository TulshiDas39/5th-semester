basePrice = quantity * itemPrice
finalPrice = discountedPrice(basePrice)