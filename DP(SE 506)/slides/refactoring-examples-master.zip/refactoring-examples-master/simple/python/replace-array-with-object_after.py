row = Performance();
row.setName("Liverpool")
row.setWins("15")