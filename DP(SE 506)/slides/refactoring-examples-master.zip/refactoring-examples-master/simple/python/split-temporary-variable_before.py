temp = 2 * (height + width)
print(temp)
temp = height * width
print(temp)