class Customer {
  private String name = "name";
  private String lastName = "lastname";

  /**
   * Method returns customer's lastname.
   */
  String getlnm() {
    return lastName;
  }

  // other methods ...
}