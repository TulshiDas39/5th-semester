class Employee {
  Employee(int type) {
    this.type = type;
  }
  //...
}