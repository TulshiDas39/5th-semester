class Soldier {
  public int health;
  public int damage;
  public int weaponStatus;
  public int getDamage() {
   //... 
  }
  public void attack() {
   //... 
  }
}