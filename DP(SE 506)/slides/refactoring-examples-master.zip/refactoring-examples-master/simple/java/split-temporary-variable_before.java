double temp = 2 * (height + width);
System.out.println(temp);
temp = height * width;
System.out.println(temp);