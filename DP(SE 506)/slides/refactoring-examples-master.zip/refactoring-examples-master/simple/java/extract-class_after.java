class Soldier {
  public int health;
  public Weapon weapon;
  public void attack() {
    //...
  }
}

class Weapon {
  public int damage;
  public int weaponStatus;
  public int getDamage() {
    //...
  }
}