int basePrice = quantity * itemPrice;
double finalPrice = discountedPrice(basePrice);