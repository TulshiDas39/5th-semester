void setHeight(int arg) {
  height = arg;
}
void setWidth(int arg) {
  width = arg;
}