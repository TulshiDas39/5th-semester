String[] row = new String[2];
row[0] = "Liverpool";
row[1] = "15";