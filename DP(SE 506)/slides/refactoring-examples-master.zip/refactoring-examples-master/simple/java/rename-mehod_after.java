class Customer {
  private String name = "name";
  private String lastName = "lastname";

  String getLastName() {
    return lastName;
  }

  // other methods ...
}