<?php
function foundPerson(array $people){
  for ($i = 0; $i < count($people); $i++) {
    if ($people[$i] == "Don") {
      return "Don";
    }
    if ($people[$i] == "John") {
      return "John";
    }
    if ($people[$i] =="Kent") {
      return "Kent";
    }
  }
  return "";
}