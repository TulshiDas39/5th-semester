<?php
$row = array();
$row[0] = "Liverpool";
$row[1] = 15;