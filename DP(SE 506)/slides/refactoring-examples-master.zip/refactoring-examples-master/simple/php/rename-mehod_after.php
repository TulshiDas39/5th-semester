<?php
class Customer {
  private $name = "name";
  private $lastName = "lastname";

  function getLastName() {
    return $this->lastName;
  }

  // other methods ...
}
