<?php
return $anOrder->basePrice() > 1000;