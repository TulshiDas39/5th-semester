<?php
class Employee {
  ...
  function __construct($type) {
   $this->type = $type;
  }
  ...
}