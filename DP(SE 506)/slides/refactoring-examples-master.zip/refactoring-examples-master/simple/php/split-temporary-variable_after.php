<?php
$perimeter = 2 * ($this->height + $this->width);
print($perimeter);
$area = $this->height * $this->width;
print($area);