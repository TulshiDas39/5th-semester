<?php
$withinPlan = $plan->withinRange($daysTempRange);