<?php
function potentialEnergy($mass, $height) {
  return $mass * $height * 9.81;
}