<?php
function disabilityAmount() {
  if ($this->isNotEligableForDisability()) return 0;
  // compute the disability amount
  ...