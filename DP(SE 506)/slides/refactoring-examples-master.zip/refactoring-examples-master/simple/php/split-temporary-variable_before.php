<?php
$temp = 2 * ($this->height + $this->width);
print($temp);
$temp = $this->height * $this->width;
print($temp);