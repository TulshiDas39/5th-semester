<?php
class Customer {
  private $name = "name";
  private $lastName = "lastname";

  /**
   * Method returns customer's lastName.
   */
  function getsnm() {
    return $this->lastName;
  }

  // other methods ...
}
