<?php
public $name;