<?php
private $name;

public getName() {
  return $this->name;
}

public setName($arg) {
  $this->name = $arg;
}