double DisabilityAmount() 
{
  if (IsNotEligableForDisability()) 
  {
    return 0;
  }
  // compute the disability amount
  //...
}