class Person 
{
  public string name;
}