public class Employee
{
  public static Employee Create(int type)
  {
    employee = new Employee(type);
    // do some heavy lifting.
    return employee;
  }
  //...
}