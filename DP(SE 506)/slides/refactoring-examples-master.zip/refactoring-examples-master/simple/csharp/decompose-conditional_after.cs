if (NotSummer(date)) 
{
  charge = WinterCharge(quantity);
}
else 
{
  charge = SummerCharge(quantity);
}