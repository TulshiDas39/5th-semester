int basePrice = quantity * itemPrice;
double finalPrice = DiscountedPrice(basePrice);