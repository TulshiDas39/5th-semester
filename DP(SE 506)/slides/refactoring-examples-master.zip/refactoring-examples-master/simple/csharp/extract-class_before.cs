class Soldier 
{
  public int Health
  { get; set; }
  public int Damage
  { get; set; }
  public int WeaponStatus
  { get; set; }
  
  public int GetDamage() 
  {
   //... 
  }
  public void Attack() 
  {
   //... 
  }
}