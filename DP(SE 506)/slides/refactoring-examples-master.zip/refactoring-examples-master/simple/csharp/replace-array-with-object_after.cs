Performance row = new Performance();
row.SetName("Liverpool");
row.SetWins("15");