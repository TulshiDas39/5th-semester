public class Employee 
{
  public Employee(int type) 
  {
    this.type = type;
  }
  //...
}