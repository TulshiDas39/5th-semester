int Discount(int inputVal, int quantity) 
{
  if (inputVal > 50) 
  {
    inputVal -= 2;
  }
  //...
}