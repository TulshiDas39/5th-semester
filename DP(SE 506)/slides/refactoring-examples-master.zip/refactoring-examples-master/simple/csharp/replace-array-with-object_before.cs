string[] row = new string[2];
row[0] = "Liverpool";
row[1] = "15";