/**
 *
 */

package dt;


public class UnknownDecisionException extends Exception {
  public UnknownDecisionException(String attribute, String decision) {
    super();
  }
}

