/**
 *
 */

package dt;

public class BadDecisionException extends Exception {
}

